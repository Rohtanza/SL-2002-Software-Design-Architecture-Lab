/**
 * class representing a Supplier for raw materials.
 */
public class Supplier {
    /**
     * unique identifier for the supplier.
     */
    private String supplierID;

    /**
     * name of supplier.
     */
    private String supplierName;

    /**
     * contact information of supplier.
     */
    private String contactInfo;

    /**
     * Constructor to Supplier object.
     *
     * @param supplierID    unique identifier for supplier.
     * @param supplierName  name of  supplier.
     * @param contactInfo   contact information of supplier.
     */
    public Supplier(String supplierID, String supplierName, String contactInfo) {
        this.supplierID = supplierID;
        this.supplierName = supplierName;
        this.contactInfo = contactInfo;
    }

    /**
     * retrieves  details of  supplier.
     *
     * @return string containing  supplier details.
     */
    public String getDetails() {
        return "Supplier ID: " + supplierID + ", Name: " + supplierName + ", Contact: " + contactInfo;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }
}
