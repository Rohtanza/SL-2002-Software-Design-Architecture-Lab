import java.util.Date;

/**
 * class representing a in the system.
 */
public class Purchase {
    /**
     * unique identifier for the purchase.
     */
    private String purchaseID;

    /**
     * identifier for the raw material purchased.
     */
    private String materialID;

    /**
     * quantity of the raw material purchased.
     */
    private int quantity;

    /**
     * date of purchase.
     */
    private Date dateOfPurchase;

    /**
     * identifier for supplier from whom material was purchased.
     */
    private String supplierID;

    /**
     * constructor to Purchase object.
     *
     * @param purchaseID     unique identifier for purchase.
     * @param materialID     identifier for raw material purchased.
     * @param quantity       quantity of raw material purchased.
     * @param dateOfPurchase date of purchase.
     * @param supplierID     identifier for supplier.
     */
    public Purchase(String purchaseID, String materialID, int quantity, Date dateOfPurchase, String supplierID) {
        this.purchaseID = purchaseID;
        this.materialID = materialID;
        this.quantity = quantity;
        this.dateOfPurchase = dateOfPurchase;
        this.supplierID = supplierID;
    }

    /**
     * creates a purchase order.
     */
    public void createPurchaseOrder(RawMaterial material, int quantity) {
        this.materialID = material.getMaterialID();
        this.quantity = quantity;
        this.dateOfPurchase = new Date();
        this.supplierID = material.getSupplierID();
        System.out.println("Purchase Order Created for Material ID: " + material.getMaterialID() + ", Quantity: " + quantity);
    }

    /**
     * generates an invoice for purchase.
     *
     * @return string containing invoice details.
     */
    public String generateInvoice() {
        return "Invoice for Purchase ID: " + purchaseID;
    }

    // getters and setters
    public String getPurchaseID() {
        return purchaseID;
    }

    public void setPurchaseID(String purchaseID) {
        this.purchaseID = purchaseID;
    }

    public String getMaterialID() {
        return materialID;
    }

    public void setMaterialID(String materialID) {
        this.materialID = materialID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getDateOfPurchase() {
        return dateOfPurchase;
    }

    public void setDateOfPurchase(Date dateOfPurchase) {
        this.dateOfPurchase = dateOfPurchase;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }
}
