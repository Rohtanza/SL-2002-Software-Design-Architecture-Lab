import java.util.Date;

/**
 * class representing a Sale in system.
 */
public class Sale {
    /**
     * unique identifier for sale.
     */
    private String saleID;

    /**
     * identifier for product sold.
     */
    private String productID;

    /**
     * quantity of product sold.
     */
    private int quantity;

    /**
     * date of sale.
     */
    private Date dateOfSale;

    /**
     * constructor to initialize a Sale object.
     *
     * @param saleID     unique identifier for sale.
     * @param productID  identifier for product sold.
     * @param quantity   quantity of product sold.
     * @param dateOfSale date of sale.
     */
    public Sale(String saleID, String productID, int quantity, Date dateOfSale) {
        this.saleID = saleID;
        this.productID = productID;
        this.quantity = quantity;
        this.dateOfSale = dateOfSale;
    }

    /**
     * creates a sale order.
     */
    public void createSaleOrder(Product product, int quantity) {
        this.productID = product.getProductID();
        this.quantity = quantity;
        this.dateOfSale = new Date();
        System.out.println("Sale Order Created for Product ID: " + product.getProductID() + ", Quantity: " + quantity);
    }


    /**
     * generates an invoice for sale.
     *
     * @return string containing invoice details.
     */
    public String generateInvoice() {
        return "Invoice for Sale ID: " + saleID;
    }

    // getters and setters
    public String getSaleID() {
        return saleID;
    }

    public void setSaleID(String saleID) {
        this.saleID = saleID;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getDateOfSale() {
        return dateOfSale;
    }

    public void setDateOfSale(Date dateOfSale) {
        this.dateOfSale = dateOfSale;
    }
}
