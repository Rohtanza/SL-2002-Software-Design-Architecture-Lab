/**
 * class representing a Raw Material
 */
public class RawMaterial {
    /**
     * unique identifier for raw material.
     */
    private String materialID;

    /**
     * name of raw material.
     */
    private String materialName;

    /**
     * quantity of raw material.
     */
    private int quantity;

    /**
     * identifier for supplier of raw material.
     */
    private String supplierID;

    /**
     * Constructor to RawMaterial object.
     *
     * @param materialID   Unique identifier for the raw material.
     * @param materialName Name of the raw material.
     * @param quantity     Quantity of the raw material.
     * @param supplierID   Identifier for the supplier of the raw material.
     */
    public RawMaterial(String materialID, String materialName, int quantity, String supplierID) {
        this.materialID = materialID;
        this.materialName = materialName;
        this.quantity = quantity;
        this.supplierID = supplierID;
    }

    /**
     * retrieves the details of raw material.
     *
     * @return string containing raw material details.
     */
    public String getDetails() {
        return "Material ID: " + materialID + ", Name: " + materialName + ", Quantity: " + quantity +
                ", Supplier ID: " + supplierID;
    }

    public String getMaterialID() {
        return materialID;
    }

    public void setMaterialID(String materialID) {
        this.materialID = materialID;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }
}
