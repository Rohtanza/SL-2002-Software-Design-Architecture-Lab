import java.util.Date;

/**
 * class representing product in inventory system.
 */
public class Product {
    /**
     * unique identifier for the product.
     */
    private String productID;

    /**
     * name of the product.
     */
    private String productName;

    /**
     * batch number of the product.
     */
    private String batchNumber;

    /**
     * manufacture date of the product.
     */
    private Date manufactureDate;

    /**
     * expiry date of the product.
     */
    private Date expiryDate;

    /**
     * constructor to Product object.
     *
     * @param productID       Unique identifier for the product.
     * @param productName     Name of the product.
     * @param batchNumber     Batch number of the product.
     * @param manufactureDate Manufacture date of the product.
     * @param expiryDate      Expiry date of the product.
     */
    public Product(String productID, String productName, String batchNumber, Date manufactureDate, Date expiryDate) {
        this.productID = productID;
        this.productName = productName;
        this.batchNumber = batchNumber;
        this.manufactureDate = manufactureDate;
        this.expiryDate = expiryDate;
    }

    /**
     * retrieves the details of the product
     *
     * @return string containing the product details
     */
    public String getDetails() {
        return "Product ID: " + productID + ", Name: " + productName + ", Batch: " + batchNumber +
                ", Mfg Date: " + manufactureDate + ", Expiry Date: " + expiryDate;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public Date getManufactureDate() {
        return manufactureDate;
    }

    public void setManufactureDate(Date manufactureDate) {
        this.manufactureDate = manufactureDate;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }
}
