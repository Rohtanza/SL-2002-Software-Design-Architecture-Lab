
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.Date;

public class Main {

    @Test
    public void main() {
        Date manufactureDate = new Date();
        Date expiryDate = new Date(manufactureDate.getTime() + (1000 * 60 * 60 * 24 * 365));
        Product product = new Product("SDA", "Lab exam", "1", manufactureDate, expiryDate);
        RawMaterial material = new RawMaterial("Lab", "Lab", 1, "Lab");

        Inventory inventory = new Inventory("Lab", "Lab", 0, "Lab");
        Sale sale = new Sale("Lab", "Lab", 0, new Date());
        Purchase purchase = new Purchase("Lab", "Lab", 0, new Date(), "Lab");

        inventory.addProduct(product, 1);

        inventory.removeProduct(product, 2);

        sale.createSaleOrder(product, 3);

        purchase.createPurchaseOrder(material, 4);

        //Testing Question 04
        assertEquals("SDA", product.getProductID());
        assertEquals("Lab exam", product.getProductName());
        assertEquals("1", product.getBatchNumber());
        assertEquals(manufactureDate, product.getManufactureDate());
        assertEquals(expiryDate, product.getExpiryDate());
    }


}
