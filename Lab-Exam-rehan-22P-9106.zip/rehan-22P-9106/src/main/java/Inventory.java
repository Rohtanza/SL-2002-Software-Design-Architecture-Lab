/**
 * class representing Inventory.
 */
public class Inventory {
    /**
     * unique identifier for the inventory.
     */
    private String inventoryID;

    /**
     * unique identifier for the product stored in the inventory.
     */
    private String productID;

    /**
     * quantity of the product in the inventory.
     */
    private int quantity;

    /**
     * batch number of the product in the inventory.
     */
    private String batchNumber;

    /**
     * constructor to initialize Inventory object.
     *
     * @param inventoryID unique identifier for inventory.
     * @param productID   unique identifier for product.
     * @param quantity    quantity of product.
     * @param batchNumber batch number of product.
     */
    public Inventory(String inventoryID, String productID, int quantity, String batchNumber) {
        this.inventoryID = inventoryID;
        this.productID = productID;
        this.quantity = quantity;
        this.batchNumber = batchNumber;
    }

    /**
     * adds a product to inventory.
     */
    public void addProduct(Product product, int quantity) {
        this.productID = product.getProductID();
        this.quantity += quantity;
        this.batchNumber = product.getBatchNumber();
        System.out.println("Added " + quantity + " units of Product ID: " + product.getProductID() + " to inventory.");
    }


    /**
     * Removes a product from inventory.
     */
    public void removeProduct(Product product, int quantity) {
        if (this.productID.equals(product.getProductID()) && this.quantity >= quantity) {
            this.quantity -= quantity; // Decrementing the quantity
            System.out.println("Removed " + quantity + " units of Product ID: " + product.getProductID() + " from inventory.");
        } else {
            System.out.println("Error: Not enough quantity or product mismatch.");
        }
    }


    /**
     * checks details of inventory.
     *
     * @return string containing inventory details.
     */
    public String checkInventory() {
        return "Inventory ID: " + inventoryID + ", Product ID: " + productID +
                ", Quantity: " + quantity + ", Batch: " + batchNumber;
    }

    public String getInventoryID() {
        return inventoryID;
    }

    public void setInventoryID(String inventoryID) {
        this.inventoryID = inventoryID;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }
}
